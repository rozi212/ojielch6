//menampilkan file game
const game = (req, res) => {
    res.render('game');
}
module.exports = {
    game
}