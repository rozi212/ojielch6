const { user_gamebiodata, } = require("../models");

const showDashboard = (req, res) => {
    user_gamebiodata.findAll().then((data) => {
        res.render("dashboard", { data });
    });
};

module.exports = {
    showDashboard,
};