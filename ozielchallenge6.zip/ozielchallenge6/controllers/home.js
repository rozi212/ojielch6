//menampilkan file home
const home = (req, res) => {
    res.render('home');
}
module.exports = {
    home
}