const { user_gamebiodata } = require("../models");

const deletedataUser = (req, res) => {
    user_gamebiodata
        .destroy({
            where: {
                id: req.params.id,
            },
        })
        .then(() => {
            res.redirect("/dashboard");
        })
        .catch((err) => {
            res.send(err);
        });
};

module.exports = {
    deletedataUser,
};